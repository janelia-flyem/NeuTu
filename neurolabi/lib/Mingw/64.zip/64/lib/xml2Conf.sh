#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/local/lib"
XML2_LIBS="-lxml2     "
XML2_INCLUDEDIR="-I/usr/local/include/libxml2"
MODULE_VERSION="xml2-2.9.0"

